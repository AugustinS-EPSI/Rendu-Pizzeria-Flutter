class OptionItem {
  final int value;
  final String name;
  final int supplement;

  OptionItem(this.value, this.name, {this.supplement =0});
}