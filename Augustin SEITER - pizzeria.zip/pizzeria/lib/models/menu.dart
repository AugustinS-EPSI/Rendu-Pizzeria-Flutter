import 'dart:ui';

class Menu {
  int type;
  String title;
  String image;
  Color color;

  Menu(this.type, this.title, this.image, this.color);
}

